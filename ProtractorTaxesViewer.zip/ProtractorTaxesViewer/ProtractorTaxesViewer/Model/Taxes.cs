﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtractorTaxesViewer.Model
{
    sealed class Taxes
    {
        public double GrandTotal { get; set; }
        public double PartsTotal { get; set; }
        public double LaborTotal { get; set; }
        public double SubletTotal { get; set; }
        public double NetTotal { get; set; }
    }
}
