﻿using Microsoft.Win32;
using ProtractorTaxesViewer.Helper;
using ProtractorTaxesViewer.Model;
using System;
using System.IO;
using System.Windows.Input;
using System.Xml;

namespace ProtractorTaxesViewer.ViewModel
{
    sealed class MyViewModel : BaseClass
    {
        #region fields
        public double _grandTotalCounter = 0;

        public double _partsTotalCounter = 0;

        public double _laborTotalCounter = 0;

        public double _subletTotalCounter = 0;

        public double _netTotalCounter = 0;

        private string _defaultText;

        private string _defaultTextColor;

        private Taxes _taxes;
        #endregion

        #region Properties
        public string DefaultText
        {
            get { return _defaultText; }
            set
            {
                if (_defaultText != value)
                {
                    _defaultText = value;
                    OnPropertyChange("DefaultText");
                }
            }
        }

        public string DefaultTextColor
        {
            get { return _defaultTextColor; }
            set
            {
                if (_defaultText != value)
                {
                    _defaultTextColor = value;
                    OnPropertyChange("DefaultTextColor");
                }
            }
        }

        public double GrandTotal
        {
            get { return _taxes.GrandTotal; }
            set
            {
                if (_taxes.GrandTotal != value)
                {
                    _taxes.GrandTotal = value;
                    OnPropertyChange("GrandTotal");
                }
            }
        }

        public double PartsTotal
        {
            get { return _taxes.PartsTotal; }
            set
            {
                if (_taxes.PartsTotal != value)
                {
                    _taxes.PartsTotal = value;
                    OnPropertyChange("PartsTotal");
                }
            }
        }

        public double LaborTotal
        {
            get { return _taxes.LaborTotal; }
            set
            {
                if (_taxes.LaborTotal != value)
                {
                    _taxes.LaborTotal = value;
                    OnPropertyChange("LaborTotal");
                }
            }
        }

        public double SubletTotal
        {
            get { return _taxes.SubletTotal; }
            set
            {
                if (_taxes.SubletTotal != value)
                {
                    _taxes.SubletTotal = value;
                    OnPropertyChange("SubletTotal");
                }
            }
        }

        public double NetTotal
        {
            get { return _taxes.NetTotal; }
            set
            {
                if (_taxes.NetTotal != value)
                {
                    _taxes.NetTotal = value;
                    OnPropertyChange("NetTotal");
                }
            }
        }

        public ICommand MyCommand { get; set; }
        #endregion

        #region Constructor
        public MyViewModel()
        {
            DefaultTextColor = "red";
            DefaultText = "No files uploaded...";

            MyCommand = new RelayCommand(OpenXML, IsButtonEnable);

            _taxes = new Taxes
            {
                GrandTotal = 0.0,
                LaborTotal = 0.0,
                NetTotal = 0.0,
                PartsTotal = 0.0,
                SubletTotal = 0.0
            };
        }
        #endregion

        #region Methods
        private void OpenXML(object parameter)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.DefaultExt = ".xml";
            fileDialog.Filter = "Extensible Markup Language (.xml)|*.xml";
            bool? res = fileDialog.ShowDialog();

            if (res.HasValue && res.Value)
            {
                DefaultTextColor = "green";
                DefaultText = fileDialog.FileName + " has been successfully uploaded!";
                CalculateSums(fileDialog.FileName);

            }

            SetValues();
        }

        private void CalculateSums(string path)
        {
            StreamReader sr = new StreamReader(path);
            XmlDocument doc = new XmlDocument();
            doc.Load(sr);

            string[] allTotals = { "PartsTotal", "GrandTotal", "LaborTotal", "SubletTotal", "NetTotal" };
            XmlNodeList elemList;

            for (int j = 0; j < allTotals.Length; j++)
            {
                elemList = doc.GetElementsByTagName(allTotals[j]);

                for (int i = 0; i < elemList.Count; i++)
                {
                    switch (allTotals[j])
                    {
                        case "GrandTotal":
                            _grandTotalCounter = _grandTotalCounter + (Convert.ToDouble(elemList[i].InnerXml));
                            break;
                        case "PartsTotal":
                            _partsTotalCounter = _partsTotalCounter + (Convert.ToDouble(elemList[i].InnerXml));
                            break;
                        case "LaborTotal":
                            _laborTotalCounter = _laborTotalCounter + (Convert.ToDouble(elemList[i].InnerXml));
                            break;
                        case "SubletTotal":
                            _subletTotalCounter = _subletTotalCounter + (Convert.ToDouble(elemList[i].InnerXml));
                            break;
                        case "NetTotal":
                            _netTotalCounter = _netTotalCounter + (Convert.ToDouble(elemList[i].InnerXml));
                            break;
                    }

                }
            }
        }

        private bool IsButtonEnable(object parameter)
        {
            return true;
        }
        #endregion

        #region helper methods
        private void SetValues()
        {
            GrandTotal = GrandTotalResult();
            PartsTotal = PartsTotalResult();
            LaborTotal = LaborTotalResult();
            SubletTotal = SubletTotalResults();
            NetTotal = NetTotalResults();
        }

        public double GrandTotalResult()
        {
            return Round(_grandTotalCounter);
        }

        public double PartsTotalResult()
        {
            return Round(_partsTotalCounter);
        }

        public double LaborTotalResult()
        {
            return Round(_laborTotalCounter);
        }

        public double SubletTotalResults()
        {
            return Round(_subletTotalCounter);
        }

        public double NetTotalResults()
        {
            return Round(_netTotalCounter);
        }

        public double Round(double counter)
        {
            return Math.Round(counter, 2);
        }
        #endregion
    }
}
