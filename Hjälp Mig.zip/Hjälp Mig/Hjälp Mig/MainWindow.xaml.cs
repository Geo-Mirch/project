﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hjälp_Mig
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Thickness LeftSide = new Thickness(1, 1, 0, 0);
        Thickness RightSide = new Thickness(0, 0, 19, 0); // move of on off button inside trigger
        SolidColorBrush Off = new SolidColorBrush(Color.FromRgb(160, 160, 160));
        SolidColorBrush On = new SolidColorBrush(Color.FromRgb(130, 190, 125));
        private bool Toggled = false;

        public bool Toggled1 { get => Toggled; set => Toggled = value; }

        public MainWindow()
        {
            InitializeComponent();
            Storyboard slideIn = this.Resources["SlideIn"] as Storyboard;
            //slidein.Begin();               
            TopLogin.Visibility = Visibility.Visible;
            //Animation
            TimeSpan duration = new TimeSpan(0, 0, 1);
            DoubleAnimation animation = new DoubleAnimation();
            animation.From = 0.0;
            animation.To = 1.0;
            animation.Duration = new Duration(duration);
            Storyboard.SetTargetName(animation, LogInPanel.Name);
            Storyboard.SetTargetProperty(animation, new PropertyPath(Control.OpacityProperty));
            slideIn.Children.Add(animation);
            slideIn.Begin(this);



            // Unblock all events
            EnableButtonsPanel.Visibility = Visibility.Hidden;
            EnableButtonsPanelRegistration.Visibility = Visibility.Hidden;
            //End Animation
            NoProfileImage.MouseMove += new MouseEventHandler(NoProfileImage_MouseMove);
            NoProfileImage.MouseLeave += new MouseEventHandler(NoProfileImage_MouseLeave);
            changeProfileImage.MouseMove += new MouseEventHandler(changeProfileImage_MouseMove);
            changeProfileImage.MouseLeave += new MouseEventHandler(changeProfileImage_MouseLeave);
            changeProfileImage.MouseLeftButtonUp += new MouseButtonEventHandler(changeProfileImage_MouseClick);


            Back.Fill = Off;
            Toggled = false;
            Dot.Margin = LeftSide;
        }
        private void NoProfileImage_MouseMove(object sender, EventArgs e)
        {
            changeProfileImage.Visibility = Visibility.Visible;
        }
        private void NoProfileImage_MouseLeave(object sender, EventArgs e)
        {
            changeProfileImage.Visibility = Visibility.Hidden;
        }
        private void changeProfileImage_MouseMove(object sender, EventArgs e)
        {
            changeProfileImage.Visibility = Visibility.Visible;
        }
        private void changeProfileImage_MouseLeave(object sender, EventArgs e)
        {
            changeProfileImage.Visibility = Visibility.Hidden;
        }
        private void changeProfileImage_MouseClick(object sender, EventArgs e)
        {

        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            Storyboard slideOut = this.Resources["SlideOut"] as Storyboard;
            //slidein.Begin();               

            //Animation
            TimeSpan duration = new TimeSpan(0, 0, 1);
            DoubleAnimation animation = new DoubleAnimation();
            animation.From = 1.0;
            animation.To = 0.0;
            animation.Duration = new Duration(duration);
            Storyboard.SetTargetName(animation, LogInPanel.Name);
            Storyboard.SetTargetProperty(animation, new PropertyPath(Control.OpacityProperty));
            slideOut.Children.Add(animation);
            slideOut.Begin(this);

            Storyboard slideInReg = this.Resources["SlideInRegistration"] as Storyboard;
            TimeSpan durationReg = new TimeSpan(0, 0, 1);
            DoubleAnimation animationAnime = new DoubleAnimation();
            animationAnime.From = 0.0;
            animationAnime.To = 1.0;
            animationAnime.Duration = new Duration(durationReg);
            Storyboard.SetTargetName(animationAnime, RegInPanel.Name);
            Storyboard.SetTargetProperty(animationAnime, new PropertyPath(Control.OpacityProperty));
            slideInReg.Children.Add(animationAnime);
            slideInReg.Begin(this);

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Storyboard slideOut = this.Resources["SlideOutRegistration"] as Storyboard;
            //slidein.Begin();               

            //Animation
            TimeSpan duration = new TimeSpan(0, 0, 1);
            DoubleAnimation animation = new DoubleAnimation();
            animation.From = 1.0;
            animation.To = 0.0;
            animation.Duration = new Duration(duration);
            Storyboard.SetTargetName(animation, RegInPanel.Name);
            Storyboard.SetTargetProperty(animation, new PropertyPath(Control.OpacityProperty));
            slideOut.Children.Add(animation);
            slideOut.Begin(this);
            // da optimiziram koda 4e ima povtarqshti se neshta
            Storyboard slideInReg = this.Resources["SlideIn"] as Storyboard;
            TimeSpan durationReg = new TimeSpan(0, 0, 1);
            DoubleAnimation animationAnime = new DoubleAnimation();
            animationAnime.From = 0.0;
            animationAnime.To = 1.0;
            animationAnime.Duration = new Duration(durationReg);
            Storyboard.SetTargetName(animationAnime, LogInPanel.Name);
            Storyboard.SetTargetProperty(animationAnime, new PropertyPath(Control.OpacityProperty));
            slideInReg.Children.Add(animationAnime);
            slideInReg.Begin(this);
        }

        private void CloseSign_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void WindowMinimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            TopLogin.Visibility = Visibility.Hidden;
            TopRegistration.Visibility = Visibility.Hidden;
            ControlPanelVisibility.Visibility = Visibility.Visible;
            this.Left = SystemParameters.WorkArea.Left;
            this.Top = SystemParameters.WorkArea.Top;
            this.Height = SystemParameters.WorkArea.Height;
            this.Width = SystemParameters.WorkArea.Width;
            addReminder.Visibility = Visibility.Visible;

        }
        //private void Button11_Click(object sender, RoutedEventArgs e)
        //{
        //    TextBlock tx = new TextBlock()
        //    {
        //        Text = "This data already exists in the database!"
        //    };
        //    if (true)
        //    {
        //        buba.Children.Add(tx);
        //        return; // kogato danite sushtestuvavat
        //    }
        //    timi.IsOpen = false; // logika kogato dannite ne sushtestvuvat
        //}

        private void ButtonPopUpLogout_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void ButtonOpenMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonOpenMenu.Visibility = Visibility.Collapsed;
            ButtonCloseMenu.Visibility = Visibility.Visible;
        }
        private void ButtonCloseMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonOpenMenu.Visibility = Visibility.Visible;
            ButtonCloseMenu.Visibility = Visibility.Collapsed;
        }
        private void CalendarTab_Click(object sender, RoutedEventArgs e)
        {
            addReminder.Visibility = Visibility.Visible;
            addExpense.Visibility = Visibility.Hidden;
        }
        private void MoneyTab_Click(object sender, RoutedEventArgs e)
        {

            addReminder.Visibility = Visibility.Hidden;
            addExpense.Visibility = Visibility.Visible;


        }
        private void Dot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!Toggled)
            {
                Back.Fill = On;
                Toggled = true;
                Dot.Margin = RightSide;
                chepec.ImageSource = null;
                munka.Background = new SolidColorBrush(Colors.Black);
            }
            else
            {
                Back.Fill = Off;
                Toggled = false;
                Dot.Margin = LeftSide;
            }
        }

        private void Back_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!Toggled)
            {
                Back.Fill = On;
                Toggled = true;
                Dot.Margin = RightSide;
                chepec.ImageSource = null;
                munka.Background = new SolidColorBrush(Colors.Black);
            }
            else
            {
                Back.Fill = Off;
                Toggled = false;
                Dot.Margin = LeftSide;
            }
        }

        //private void GearShift_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    gearShiftLine.Visibility = Visibility.Visible;
        //    gearShiftImg.Opacity = 0.5;
        //    oilLine.Visibility = Visibility.Hidden;
        //    oilImg.Opacity = 1;
        //}
        //private void Oil_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    oilLine.Visibility = Visibility.Visible;
        //    oilImg.Opacity = 0.5;
        //    gearShiftLine.Visibility = Visibility.Hidden;
        //    gearShiftImg.Opacity = 1;
        //}

        //private void CarKeyImg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        //{
        //    Image btn = (Image)sender;
        //    var buba = btn.Name;
        //}

        private void SelectedIcon_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Image selectedImage = (Image)sender;
            SelectedItem(selectedImage);

        }



        private void UploadFile_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.AddExtension = true;

            if (fileDialog.ShowDialog() == true)
            {
                string targetPath = @"C:\Hjälp Mig";

                if (!Directory.Exists(targetPath))
                {
                    DirectoryInfo di = Directory.CreateDirectory(targetPath);
                }

                string destFile = System.IO.Path.Combine(targetPath, System.IO.Path.GetFileName(fileDialog.FileName));
                File.Move(fileDialog.FileName, destFile);

            }

            loaderGif.Visibility = Visibility.Visible;

            // to think how to hide loadergif-a

        }





        void SelectedItem(Image itemName)
        {
            Dictionary<Image, Grid> openWith = new Dictionary<Image, Grid>();
            openWith.Add(gearShiftImg, gearShiftLine);
            openWith.Add(oilImg, oilLine);
            openWith.Add(carKeyImg, carKeyLine);
            openWith.Add(tempImg, tempLine);
            openWith.Add(exhaustImg, exhaustLine);
            openWith.Add(batteryImg, batteryLine);
            openWith.Add(windowImg, windowLine);
            openWith.Add(parkingImg, parkingLine);
            openWith.Add(sparkPlugImg, sparkPlugLine);
            openWith.Add(breakImg, breakLine);

            foreach (var item in openWith)
            {
                item.Key.Opacity = 1;
                item.Value.Visibility = Visibility.Hidden;

                if (item.Key.Name == itemName.Name)
                {
                    item.Value.Visibility = Visibility.Visible;
                    itemName.Opacity = 0.3;
                }
            }
        }
    }
}
